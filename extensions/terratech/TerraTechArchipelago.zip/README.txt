TerraTech Archipelago mod
Drop this folder in <TerraTech>/QMods/TerraTechArchipelago/
Source: https://github.com/solida1987/TerraTech-Archipelago
